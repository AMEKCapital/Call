### Connect Odoo client and 3CX Phone for Windows


Please read _*threecx/static/description/index.html*_ for details.
