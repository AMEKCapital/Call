﻿using System;

namespace NodoCRMPlugin
{
    class BaseCmd
    {
        public String Action { set; get; }
    }
}
