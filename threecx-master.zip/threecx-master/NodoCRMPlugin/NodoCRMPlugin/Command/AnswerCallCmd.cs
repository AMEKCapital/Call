﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NodoCRMPlugin.Command
{
    class AnswerCallCmd : BaseCmd
    {
        public String CallID { get; set; }
    }
}
